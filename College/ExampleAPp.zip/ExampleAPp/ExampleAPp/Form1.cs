﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleAPp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            columnID.DataType = Type.GetType("System.Int32");
            columnID.AllowDBNull = false;
            columnID.AutoIncrement = true;
            columnID.Unique = true;
            //columnID.ColumnName = "ID";

            columnFirstName.AllowDBNull = false;
            columnFirstName.DataType = Type.GetType("System.String");
            //columnFirstName.ColumnName = "FirstName";

            columnLastName.AllowDBNull = false;
            columnLastName.DefaultValue = "-";
            columnLastName.DataType = Type.GetType("System.String");
            //columnLastName.ColumnName = "LastName";

            columnParentName.AllowDBNull = false;
            columnParentName.DataType = Type.GetType("System.String");
            //columnParentName.ColumnName = "ParentName";

            columnPostName.AllowDBNull = false;
            columnPostName.DataType = Type.GetType("System.String");
            //columnPostName.ColumnName = "PostName";

            columnPhone.AllowDBNull = false;
            columnPhone.Unique = true;
            columnPhone.DataType = Type.GetType("System.String");
            //columnPhone.ColumnName = "Phone";

            tableEmployee.Columns.Add(columnID);
            tableEmployee.Columns.Add(columnFirstName);
            tableEmployee.Columns.Add(columnLastName);
            tableEmployee.Columns.Add(columnParentName);
            tableEmployee.Columns.Add(columnPostName);
            tableEmployee.Columns.Add(columnPhone);

            dataSet.Tables.Add(tableEmployee);

            dataSet.Tables[0].Rows.Add(new Object[] {null, "И", "И", "И", "О", "+7(999)999-99-99" });
            dataSet.Tables[0].Rows.Add(new Object[] {null, "Л", "Л", "Л", "О", "+7(888)999-99-99" });
            dataSet.Tables[0].Rows.Add(new Object[] {null, "А", "А", "А", "Н", "+7(777)999-99-99" });
            dataSet.Tables[0].Rows.Add(new Object[] {null, "Ш", "Ш", "Ш", "Н", "+7(666)999-99-99" });
        }

        DataSet dataSet = new DataSet();
        DataTable tableEmployee = new DataTable("Employee");
        DataColumn columnID = new DataColumn();
        DataColumn columnFirstName = new DataColumn();
        DataColumn columnLastName = new DataColumn();
        DataColumn columnParentName = new DataColumn();
        DataColumn columnPostName = new DataColumn();
        DataColumn columnPhone = new DataColumn();

        private void EmployeeFill()
        {
            dataGridView1.DataSource = dataSet.Tables[0];
            dataGridView1.Columns[0].HeaderText = "Код сотрудника";
            dataGridView1.Columns[1].HeaderText = "Имя";
            dataGridView1.Columns[2].HeaderText = "Фамилия";
            dataGridView1.Columns[3].HeaderText = "Отчество";
            dataGridView1.Columns[4].HeaderText = "Должность";
            dataGridView1.Columns[5].HeaderText = "Телефон";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            EmployeeFill();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataSet.Tables[0].Rows.Add(new Object[] { null, textBox1.Text, textBox2.Text, textBox3.Text, "", maskedTextBox1.Text });
        }
    }
}
